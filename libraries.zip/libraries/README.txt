This library is derived from Adafruit_GFX library, only for SSD1306 in I2C Mode.    

http://www.geekonfire.com/wiki/index.php?title=I2C_OLED_Panel(128x64)

GeekOnFire invests time and resources providing this open source code, 
please support GeekOnFire and open-source hardware by purchasing 
products from GeekOnFire!

Original Author: Limor Fried/Ladyada��Adafruit Industries��
Modified by: Jimbo.we(www.geekonfire.com)
BSD license, check license.txt for more information
All text above must be included in any redistribution

Visit http://www.geekonfire.com/wiki/index.php?title=I2C_OLED_Panel(128x64) to download. Uncompressed folder GOFi2cOLED.zip/rar, place the GOFi2cOLED library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.
